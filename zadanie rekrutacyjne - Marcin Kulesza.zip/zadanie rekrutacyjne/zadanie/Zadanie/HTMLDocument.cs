﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;


namespace Zadanie
{
    /// <summary>
    /// Class contains methods for counting Keywords occurences in HTML document 
    /// </summary>
    public class HTMLDocument
    { 
        private string html; // Content of the HTML page

        // Constructor loads HTML page content for given URL
        /// <param>
        /// URL of HTML page
        /// </param>
        public HTMLDocument(string url)
        {
            if (url != "")
            {
                html = new WebClient().DownloadString(url);
            }
            else // use sample text for unit tests
            {
                html = "<!DOCTYPE html><html lang=\"pl\"    <head><meta charset=\"iso - 8859 - 2\"><meta http-equiv=\"X - UA - Compatible\" content=\"IE = Edge\" /><link rel=\"shortcut icon\" href=\" / img / gazeta.ico\"><!-- Keywords module --><meta name=\"Keywords\" content=\"wakacjach, podróże, wycieczki, last minute\">    </head>    <body><div id=\"019 - TOPLAYER\" class=\"adviewDFPBanner DFP-019 - TOPLAYER\">Na wakacjach lubimy podróże last minute i lubimy wycieczki. Wakacjachpodróżewycieczki wakacjach wakacjachpodróże</div>    </body></html>";
            }
        }

        // In HTML Keywords are defined in the meta tag with name: Keywords e.g. :<meta name="Keywords" content="klucz, Google, SEO, pozycjonowanie">
        /// <summary>
        /// Function search for Keywords in HTML document
        /// </summary>
        /// <returns>
        /// String array with found keywords
        /// </returns>
        private string[] FindKeywordsInHTML()
        {
            string[] result = new string[0];

            string metaTagWithKeywords = ""; // This string will contain meta tag with Keywords
            
            // Find all <meta> tags
            MatchCollection matches = Regex.Matches(html, "<meta.+?\">", RegexOptions.IgnoreCase);

            foreach (Match match in matches)
            {
                // Search for meta tag with Keywords
                MatchCollection matchesKeyword = Regex.Matches(match.Groups[0].Value, "keywords", RegexOptions.IgnoreCase);
                if (matchesKeyword.Count == 1)
                {
                    metaTagWithKeywords = match.Groups[0].Value;
                    break;
                }
            }

            // If meta tag with keywords was not found
            if (metaTagWithKeywords == "")
                return result;

            // Search for "content" word in Keywords meta tag
            matches = Regex.Matches(metaTagWithKeywords, "content.*", RegexOptions.IgnoreCase);

            // If content was not found in meta tag
            if (matches.Count != 1)
                return result;

            string content = matches[0].Groups[0].Value;

            matches = Regex.Matches(content, "\".+?\"", RegexOptions.IgnoreCase);

            // If content is empty
            if (matches.Count == 0)
                return result;

            // Get Keywords from content
            string keywordsString = matches[0].Groups[0].Value;
            keywordsString = keywordsString.Replace("\"", "");            
            result = keywordsString.Split(',');
            // Remove spaces
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = result[i].Trim();
            }

            return result;
        }

        /// <summary>
        /// Function gets Keywords occurence statisc in HTML document
        /// </summary>
        /// <returns>
        /// List of ResultElement
        /// </returns>
        public List<ResultElement> GetKeywordsStatistics()
        {
            List<ResultElement> result = new List<ResultElement>();

            // Get Keywords 
            string[] keywords = FindKeywordsInHTML();

            for (int i = 0; i < keywords.Length; i++)
            {
                MatchCollection matches = Regex.Matches(html, keywords[i], RegexOptions.IgnoreCase);
                ResultElement resultElement = new ResultElement();
                resultElement.keyword = keywords[i];
                resultElement.count = matches.Count;

                result.Add(resultElement);
            }

            ResultElementSort resultElementSort = new ResultElementSort();
            result.Sort(resultElementSort);

            return result;
        }
    }
}
