﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Set ListView to be owner drawn 
            listView1.OwnerDraw = true;

            // Set to details view.
            listView1.View = View.Details;
            // Add a column
            listView1.Columns.Add("Słowo kluczowe", 780, HorizontalAlignment.Left);
            // Add a column
            listView1.Columns.Add("Ilość wystąpień", 100, HorizontalAlignment.Left);

            // Add owner draw event handlers
            listView1.DrawColumnHeader += new DrawListViewColumnHeaderEventHandler(listView1_DrawColumnHeader);
            listView1.DrawSubItem += new DrawListViewSubItemEventHandler(listView1_DrawSubItem);

            button1.Enabled = false;
        }

        // Draw ListView header
        private void listView1_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.LightBlue, e.Bounds);
            e.DrawText();
        }

        // Draw ListView item
        private void listView1_DrawSubItem(object sender, DrawListViewSubItemEventArgs e)
        {
            e.DrawBackground();
            e.DrawText();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Clear ListView
            listView1.Items.Clear();

            try
            {
                // Get Keyword statistics
                HTMLDocument htmlDocument = new HTMLDocument(textBox1.Text);                
                List<ResultElement> list = htmlDocument.GetKeywordsStatistics();

                if (list.Count() == 0)
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;

                    // Displays the MessageBox with message.
                    MessageBox.Show("Nie znaleziono słów kluczowych.", "Info", buttons);
                    return;
                }

                // Fill ListView            
                foreach (ResultElement element in list)
                {
                    ListViewItem item = new ListViewItem(new string[] { element.keyword, element.count.ToString() });
                    listView1.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                String message = ex.Message;

                MessageBoxButtons buttons = MessageBoxButtons.OK;

                // Displays the MessageBox with error message.
                MessageBox.Show(message, "Błąd", buttons);

                return;
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox1.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        }
    }
}
