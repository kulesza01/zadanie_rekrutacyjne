﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Zadanie;

namespace Zadanie_test
{
    [TestFixture]
    public class Test_HTMLDocument
    {
        [Test]
        public void Test1()
        {
            Assert.That(1 == 1);
        }

        [Test]
        public void Test2()
        {
            HTMLDocument htmlDocument = new HTMLDocument(""); // Read HTML from file
            List<ResultElement> actual = htmlDocument.GetKeywordsStatistics(); // Get result list from HTML stored in a file

            // Create list to compare with result list
            List<ResultElement> expected = new List<ResultElement>();

            ResultElement resultElement = new ResultElement();
            resultElement.keyword = "wakacjach";
            resultElement.count = 5;
            expected.Add(resultElement);

            resultElement = new ResultElement();
            resultElement.keyword = "podróże";
            resultElement.count = 4;
            expected.Add(resultElement);

            resultElement = new ResultElement();
            resultElement.keyword = "wycieczki";
            resultElement.count = 3;
            expected.Add(resultElement);

            resultElement = new ResultElement();
            resultElement.keyword = "last minute";
            resultElement.count = 2;
            expected.Add(resultElement);

            // Check if lists are the same
            Assert.That(actual, Is.EquivalentTo(expected));
        }
    }
}
