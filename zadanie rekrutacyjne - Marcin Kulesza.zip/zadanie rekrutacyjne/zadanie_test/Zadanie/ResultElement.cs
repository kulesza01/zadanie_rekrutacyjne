﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public class ResultElement
    {
        public string keyword = "";
        public int count = 0;

        public override bool Equals(object obj)
        {
            return (this.keyword == (obj as ResultElement).keyword) && (this.count == (obj as ResultElement).count);
        }
    }

    class ResultElementSort : IComparer<ResultElement>
    {
        public int Compare(ResultElement x, ResultElement y)
        {
            if (x.count == 0 || y.count == 0)
            {
                return 0;
            }

            // CompareTo() method 
            return y.count.CompareTo(x.count);
        }
    }
}
